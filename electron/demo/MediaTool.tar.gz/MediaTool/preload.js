let fs = require('fs');
let request = require('request');

function  clearCache(){
    let p1=__dirname + `/images/`;
    let p2=__dirname + `/audio/`;
    fs.readdirSync(p1).forEach(function (fileName) {
        fs.unlinkSync(p1+ fileName);
    });
    fs.readdirSync(p2).forEach(function (fileName) {
        fs.unlinkSync(p2+ fileName);
    });
}

clearCache();

window.addEventListener('DOMContentLoaded', () => {
    const { ipcRenderer } = require("electron");
    //打开网站
    var btn=window.document.getElementById('btn');
    btn.onclick=function (){
        const { shell } = require("electron");
        shell.openExternal('http://www.5nd.com');
    };

    //重置
    var resetBtn=window.document.getElementById('reset');
    resetBtn.onclick=function (){
        //全局index
        global.index=1;
        clearCache();
    };
    //解析歌曲
    var parseMusicBtn=window.document.getElementById('parseMusic');
    let player=null;
    parseMusicBtn.onclick=async function (){
        if(player){
            player.pause();
        }
       let url= document.getElementById('musicUrl').value;
       let reg=/^http:\/\/www.5nd.com\/ting\/(\d+)\.html$/ig;
       let ret=reg.exec(url);
       try{
           let musicID=ret[1];
           let musicInfoUrl=`http://geapi.5nd.com/a/ar5bc.ashx?_c=mtest&_p=bXRlc3Q&nd=get2me&t=100&ids=${musicID}`;
           //let ret=await request.get(musicInfoUrl);
           request.get({url: musicInfoUrl, maxRedirects: 100, timeout: 5000}, (error, response, body) => {
               if (!error && response.statusCode == 200) {
                    function  get2me(obj){
                        return obj;
                    }
                    let obj=eval(body);
                    let mp3Location=`http://mpge.5nd.com/${obj.data[0].location}`;
                    let name=obj.data[0].album_name||'';
                    let singer_name=obj.data[0].singer_name||'';

                   document.getElementById('musicUrl').value=`《${name}》--演唱者 --${singer_name}`;
                   document.getElementById('musicLocation').innerText=mp3Location;
                   document.getElementById('musicContent').style.display='block';
                   request(mp3Location).pipe(fs.createWriteStream(__dirname + `/audio/input.mp3`));
                   player = new Audio(mp3Location);
                   document.getElementById('playMusic').onclick=()=>{
                       player.play(); //播放 mp3这个音频对象
                   };
                   document.getElementById('pauseMusic').onclick=()=>{
                       player.pause(); //播放 mp3这个音频对象
                   };

               } else {
                   alert('音乐解析失败,请确定音乐链接正确!')
               }
           })
       }catch (e) {
           alert('音乐解析失败,请确定音乐链接正确!')
       }


    };

    //全局index
    global.index=1;
    /**
     * loadImg
     */
    ipcRenderer.on('loadImg', (event, msg) => {
        request(msg).pipe(fs.createWriteStream(__dirname + `/images/${global.index++}.jpg`));
        window.vm.images.push(msg);
    });

});


