/**
 * MediaTool
 * render.js Created by usher.yue.
 * User: usher.yue
 * Date: 2022/3/4
 * Time: 14:48
 * 乘风破浪－烟台聚货吧电子商务有限公司
 */
var vm=new Vue({
    el: '#app',
    data: {
        images: [

        ]
    }
})